# SOEN6841

Install Django and run the following commands:
1) pip install django
2) python manage.py runserver

Use the url http://127.0.0.1:8000/ in the browser
